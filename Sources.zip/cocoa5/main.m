//
//  main.m
//  cocoa5
//
//  Created by MatR on 21/11/2015.
//  Copyright © 2015 Mathieu Rossetto. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
